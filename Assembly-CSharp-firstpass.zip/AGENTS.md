<!-- UNITY CODE ASSIST INSTRUCTIONS START -->
- Project name: CasuloIndie
- Unity version: Unity 6000.2.10f1
- Active scene:
  - Name: Event1.1
  - Tags:
    - Untagged, Respawn, Finish, EditorOnly, MainCamera, Player, GameController
  - Layers:
    - Default, TransparentFX, Ignore Raycast, Water, UI, UI_A, a
- Active game object:
  - Name: Point_4
  - Tag: Untagged
  - Layer: UI
<!-- UNITY CODE ASSIST INSTRUCTIONS END -->